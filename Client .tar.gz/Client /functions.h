
#ifndef CLIENT_FUNCTIONS_H
#define CLIENT_FUNCTIONS_H

#include "memory_usage.h"
#include "common.h"
void * chat(void * socket);
void *conformation (int socket);
void *send_some_files(int socket);
void *chat2(void * socket);
void *slanje(void * socket);

struct my_thread_info {
    int thread_socket;
};


#endif
